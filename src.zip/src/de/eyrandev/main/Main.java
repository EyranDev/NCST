package de.eyrandev.main;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import net.minecraft.server.v1_8_R3.IScoreboardCriteria;
import net.minecraft.server.v1_8_R3.Packet;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardDisplayObjective;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardObjective;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardScore;
import net.minecraft.server.v1_8_R3.Scoreboard;
import net.minecraft.server.v1_8_R3.ScoreboardObjective;
import net.minecraft.server.v1_8_R3.ScoreboardScore;

public class Main extends JavaPlugin implements Listener {

	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		sendScoreboard(e.getPlayer());
		
	}
	
	public void sendScoreboard(Player p) {
		Scoreboard board = new Scoreboard();
		ScoreboardObjective obj = board.registerObjective("�cBlastMC.de", IScoreboardCriteria.b);
		
		PacketPlayOutScoreboardObjective createPacket = new PacketPlayOutScoreboardObjective(obj, 0);
		PacketPlayOutScoreboardObjective removePacket = new PacketPlayOutScoreboardObjective(obj, 1);
		PacketPlayOutScoreboardDisplayObjective display = new PacketPlayOutScoreboardDisplayObjective(1, obj);
		obj.setDisplayName("�cBlastMC.de");
		
		ScoreboardScore s01 = new ScoreboardScore(board, obj, "Du Spielst auf BlastMC.de");
		ScoreboardScore s02 = new ScoreboardScore(board, obj, p.getName());

		s01.setScore(16);
		s02.setScore(15);
		
		PacketPlayOutScoreboardScore ps01 = new PacketPlayOutScoreboardScore(s01);
		PacketPlayOutScoreboardScore ps02 = new PacketPlayOutScoreboardScore(s02);

		sendPacket(p, removePacket);
		sendPacket(p, createPacket);
		sendPacket(p, display);
		sendPacket(p, ps01);
		sendPacket(p, ps02);


	}
	
	public void sendPacket(Player p, Packet<?> packet) {
		((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet);
	}
}
